import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ManagementService {
  url = "https://api-core-dev.caronsale.de/api";
  constructor(private httpClient: HttpClient,
              private router: Router,) { }




  getAuctionBuyer(token,userId){

    const httpOptions = {
      headers: new HttpHeaders({
        userId: userId,
        authToken: token,
      }),
    };



    try
{
    this.httpClient.get(this.url+"/v2/auction/buyer/", httpOptions).subscribe(
           (res)=>{
        
               console.log("this.data",res);
              //  this.storage.setStorage("authToken",res)
              //  this.storage.getStorage("authToken")
           });
}
catch (Exception)
{
console.log("redirect to login Exception thrown ",Exception);

  this.router.navigate(["/login"]);
}


  }
}
