import { Injectable } from '@angular/core';
import { Storage } from "@ionic/storage";

@Injectable({
  providedIn: 'root'
})
export class StorageService {

  constructor(private storage: Storage) {
    
   }

  setStorage(key,val){
    this.storage.set(key,val);
  }

  getStorage(key){
    this.storage.get(key).then((res) => {
      console.log(res);
      
       return res;
  });
  }
}
