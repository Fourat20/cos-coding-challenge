import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage  implements OnInit {
  cards = [
    {
      imageUrl: '../../../assets/login/background.jpg',
      title: 'Nine Inch Nails Live',
      Erstzulassung:'Erstzulassung',
      EZ:"EZ",
      Mileage:"Mileage",
      Fuel_Type:"Fuel Type",
      highest_value  :"33.00€",
      remaining_time:"remaining time in format",
      information : 'information whether the logged in buyer is the highest bidder on an auction.'
    },
    {
      imageUrl: '../../../assets/login/background.jpg',
      title: 'Nine Inch Nails Live',
      Erstzulassung:'Erstzulassung',
      EZ:"EZ",
      Mileage:"Mileage",
      Fuel_Type:"Fuel Type",
      highest_value  :"33.00€",
      remaining_time:"remaining time in format",
      information : 'information whether the logged in buyer is the highest bidder on an auction.'
    },
    {
      imageUrl: '../../../assets/login/background.jpg',
      title: 'Nine Inch Nails Live',
      Erstzulassung:'Erstzulassung',
      EZ:"EZ",
      Mileage:"Mileage",
      Fuel_Type:"Fuel Type",
      highest_value  :"33.00€",
      remaining_time:"remaining time in format",
      information : 'information whether the logged in buyer is the highest bidder on an auction.'
    },
    {
      imageUrl: '../../../assets/login/background.jpg',
      title: 'Nine Inch Nails Live',
      Erstzulassung:'Erstzulassung',
      EZ:"EZ",
      Mileage:"Mileage",
      Fuel_Type:"Fuel Type",
      highest_value  :"33.00€",
      remaining_time:"remaining time in format",
      information : 'information whether the logged in buyer is the highest bidder on an auction.'
    },
    {
      imageUrl: '../../../assets/login/background.jpg',
      title: 'Nine Inch Nails Live',
      Erstzulassung:'Erstzulassung',
      EZ:"EZ",
      Mileage:"Mileage",
      Fuel_Type:"Fuel Type",
      highest_value  :"33.00€",
      remaining_time:"remaining time in format",
      information : 'information whether the logged in buyer is the highest bidder on an auction.'
    },];

    testreload=true
  constructor() {
  
  }

  ngOnInit() {
    setInterval(data => {
      console.log("test");
   
      // this.ReadSMSList();
      }, 3000);
  }

  cardTapped(card) {
    // while(i>5){
     
    //   setTimeout(function(){  i++;
    //     console.log("Hello"); }, 3000);
    // }
  //   do {

  //     setTimeout(() => {
  //       console.log("from second promise ")
  //       console.log('AppInitService Finished');
      
  //   }, 1000);
  // } while ( this.testreload==true)


  }
}
