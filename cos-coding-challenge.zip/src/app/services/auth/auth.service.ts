import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { StorageService } from '../storage/storage.service';
import { ManagementService } from '../management/management.service';
// import { environment } from './environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  email:string;
  password:string;
  url: string;
token
  constructor(private httpClient: HttpClient,
              private storage: StorageService,
              private management:ManagementService,
              ) { 
    this.url = "https://api-core-dev.caronsale.de/api";
  }


   login(email,password){
  this.httpClient.put(this.url+"/v1/authentication/"+email, {
    password:password,
    meta: 'string',
  }).subscribe(
         (res)=>{
        this.token=res
             console.log("this.data",this.token.token);
            //  this.storage.setStorage("authToken",res)
            //  this.storage.getStorage("authToken")
             this.management.getAuctionBuyer(null,this.token.userId)
         });

      
}



checkState(){

// check header state 
// if 200 code 

// if 401 code state 

//  if 500 code state 

}


logout(){
  // remove from ther storage the AT
}

}
