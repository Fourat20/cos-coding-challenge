import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  email:string;
  password:string;
  
  constructor(private auth:AuthService,
              private router: Router, ) { }

  ngOnInit() {
  }

  //do login
  login() {
    // send params to auth service
 this.auth.login(this.email,this.password)


// if((this.email!=="hello")||(this.password!=="hello")){
//   this.presentAlert()
// }else if((this.email==="hello")||(this.password==="hello"))
// {
//   this.router.navigate(["/home"]);
// }
  }

//if Non-Buyer registers Err Alert
  async presentAlert() {
    const alert = document.createElement('ion-alert');
    alert.header = 'Error';
    alert.message = 'Non-Buyer registers.';
    alert.buttons = ['OK'];
  
    document.body.appendChild(alert);
    await alert.present();
  }
}
